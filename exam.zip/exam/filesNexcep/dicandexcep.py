# Question 1:
# Create dictionary and print colour using key
# Handle exception if key does not exist

colors = {
    1: "Red",
    2: "Blue",
    3: "Orange"
}

try:

    key = int(input("Enter key : "))

    print("Colour :", colors[key])

except:

    print("Colour not found")
