# Question 7:
# Read from file, prepend DIOT- and write to another file

file1 = open("sample.txt", "r")

lines = file1.readlines()

file2 = open("output.txt", "w")

for line in lines:

    file2.write("DIOT-" + line)

file1.close()
file2.close()

print("Modified data written to output file")
