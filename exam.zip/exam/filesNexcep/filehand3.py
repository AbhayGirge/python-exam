# Question 6:
# Read from file and prepend each line with DIOT-

file = open("sample.txt", "r")

lines = file.readlines()

file.close()

for line in lines:

    print("DIOT-" + line.strip())
