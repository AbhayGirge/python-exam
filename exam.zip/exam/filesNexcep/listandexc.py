# Question 2:
# Create list and print value using index
# Handle exception if index does not exist

my_list = [10, 20, 30, 40, 50]

try:

    index = int(input("Enter index : "))

    print("Value :", my_list[index])

except:

    print("Value not found")
