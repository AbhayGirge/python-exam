# Question 5:
# Read from one file and write to another file

file1 = open("sample.txt", "r")

data = file1.read()

file2 = open("copy.txt", "w")

file2.write(data)

file1.close()
file2.close()

print("Data copied successfully")
