# Question 3:
# Calculate number of days lived by user
# Handle exception if days are greater than 100001

try:

    age = int(input("Enter age : "))

    days = age * 365

    if days > 100001:
        raise Exception

    print("You lived for", days, "days")

except:

    print("You lived for so long, maybe you will die soon :)")
