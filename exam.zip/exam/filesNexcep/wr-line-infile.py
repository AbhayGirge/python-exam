# Question 4:
# Write text lines entered by user into a file

file = open("sample.txt", "w")

line1 = input("Enter first line : ")
line2 = input("Enter second line : ")

file.write(line1 + "\n")
file.write(line2)

file.close()

print("Data written to file")
