# Question:
# Create Employee class and Manager subclass using inheritance

class Employee:

    # class variable
    organisation_name = "TCS"

    # constructor
    def __init__(self, emp_id, name, base_location,
                 deployed_location, designation, salary):

        self.emp_id = emp_id
        self.name = name
        self.base_location = base_location
        self.deployed_location = deployed_location
        self.designation = designation
        self.salary = salary

    # class method
    @classmethod
    def get_organisation_name(cls):
        return cls.organisation_name

    # class method
    @classmethod
    def set_organisation_name(cls, org_name):
        cls.organisation_name = org_name

    # instance method
    def get_employee_details(self):
        print("Employee ID :", self.emp_id)
        print("Employee Name :", self.name)
        print("Base Location :", self.base_location)
        print("Deployed Location :", self.deployed_location)
        print("Designation :", self.designation)
        print("Salary :", self.salary)
        print("------------------------")


# subclass
class Manager(Employee):

    def __init__(self, emp_id, name, base_location,
                 deployed_location, designation, salary):

        # calling parent constructor
        super().__init__(emp_id, name, base_location,
                         deployed_location, designation, salary)

        self.managed_employees = []

    # method to perform appraisal
    def perform_appraisal_for_an_employee(self, emp_reference, percent_raise):

        increment = emp_reference.salary * percent_raise / 100
        emp_reference.salary = emp_reference.salary + increment

        print(emp_reference.name, "salary updated to",
              emp_reference.salary)

    # manager details
    def get_manager_details(self):

        print("Manager Name :", self.name)
        print("Managed Employees :")

        for emp in self.managed_employees:
            print(emp.name)

        print("------------------------")


# main

# creating employee objects
emp1 = Employee(101, "Rahul", "Pune",
                "Mumbai", "Developer", 50000)

emp2 = Employee(102, "Amit", "Delhi",
                "Bangalore", "Tester", 40000)

emp3 = Employee(103, "Neha", "Chennai",
                "Hyderabad", "Engineer", 45000)

# creating manager object
mgr = Manager(201, "Suresh", "Pune",
              "Pune", "Manager", 90000)

# adding employees to manager list
mgr.managed_employees.append(emp1)
mgr.managed_employees.append(emp2)
mgr.managed_employees.append(emp3)

# display manager details
mgr.get_manager_details()

# appraisal for employee
mgr.perform_appraisal_for_an_employee(emp1, 10)

# display updated employee details
emp1.get_employee_details()
