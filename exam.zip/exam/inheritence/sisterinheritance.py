# Question:
# Create Person superclass and Sister and Uncle subclasses

# superclass
class Person:

    def __init__(self, name, place_of_residence):
        self.name = name
        self.place_of_residence = place_of_residence

    def display_attributes(self):
        print("Name :", self.name)
        print("Place :", self.place_of_residence)


# subclass Sister
class Sister(Person):

    def __init__(self, name, place_of_residence, exam_subjects):

        # calling parent constructor
        super().__init__(name, place_of_residence)

        self.exam_subjects = exam_subjects

    def display_attributes(self):

        super().display_attributes()

        print("Exam Subjects :", self.exam_subjects)
        print("------------------------")


# subclass Uncle
class Uncle(Person):

    def __init__(self, name, place_of_residence, business):

        # calling parent constructor
        super().__init__(name, place_of_residence)

        self.business = business

    def display_attributes(self):

        super().display_attributes()

        print("Business :", self.business)
        print("------------------------")


# main

# sister object
s1 = Sister("Priya", "Pune", "Maths, Science")

print("Sister Details")
s1.display_attributes()

# uncle object
u1 = Uncle("Ramesh", "Mumbai", "Clothing Shop")

print("Uncle Details")
u1.display_attributes()
