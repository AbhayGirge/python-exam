# Question 6:
# Calculate discounted fare

source = input("Enter source : ")

destination = input("Enter destination : ")

fare = float(input("Enter fare in INR : "))

discount_rate = float(input("Enter discount percentage : "))

discount = fare * discount_rate / 100

final_fare = fare - discount

print("Fare from", source,
      "to", destination,
      "is", fare,
      "INR after applied discount of",
      discount_rate,
      "% it is", final_fare, "INR")
