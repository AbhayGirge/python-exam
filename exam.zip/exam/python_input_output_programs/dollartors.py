# Question 5:
# Convert dollars into rupees

dollars = float(input("Enter dollars : "))

rupees = dollars * 82

print("You have", dollars, "dollars")

print("You have", rupees, "rupees")
