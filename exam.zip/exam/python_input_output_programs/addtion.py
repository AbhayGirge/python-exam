# Question 1:
# Accept two numbers from the user and print
# a) addition
# b) square of first number
# c) first number raised to second number

num1 = int(input("Enter first number : "))
num2 = int(input("Enter second number : "))

# addition
print("Addition :", num1 + num2)

# square of first number
print("Square of first number :", num1 * num1)

# power
print("Power value :", num1 ** num2)
