# Question 3:
# Calculate new salary after increment

name = input("Enter employee name : ")

salary = float(input("Enter salary : "))

increment_percentage = float(input("Enter increment percentage : "))

increment = salary * increment_percentage / 100

new_salary = salary + increment

print("Dear", name,
      "your salary is", salary,
      "rs and you have a increment of",
      increment_percentage,
      "percent, so congratulations you now have your new salary as",
      new_salary, "rs")
