# Question 2:
# Calculate profit made on stock

stock_name = input("Enter stock name : ")

buy_price = float(input("Enter buy price : "))

sell_price = float(input("Enter sell price : "))

units = int(input("Enter number of units : "))

profit = (sell_price - buy_price) * units

print("Stock Name :", stock_name)

print("Profit :", profit)
