# Question 4:
# Convert height from cms to feet

height_cm = float(input("Enter height in cms : "))

height_feet = height_cm / 30.48

print("Height in feet :", round(height_feet, 2))
