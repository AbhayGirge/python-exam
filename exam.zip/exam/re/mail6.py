# Question 7:
# Provide list of emails having numbers anywhere before @

import re

emails = [
    "gaurav1234@gmail.com",
    "pratik190900234@gmail.com",
    "JohnCena_WWE@yahoo.com"
]

pattern = r"[0-9].*@"

for email in emails:
    if re.search(pattern, email):
        print(email)
