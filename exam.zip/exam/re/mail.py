# Question 1:
# Provide list of emails having special characters # ~ ` !

import re

emails = [
    "gaurav1234@gmail.com",
    "pratik190900234@gmail.com",
    "2009_rocking_person@yahoo.com",
    "GodFather2022@yahoo.com",
    "Brocklesner_89_WWE@yahoo.com",
    "TheRock_WWE@yahoo.com",
    "JohnCena_WWE@yahoo.com",
    "Undertaker_Roman_reigns@outlook.com",
    "6789764666@rediffmail.com",
    "Kane#6789@gmail.com"
]

pattern = r"[#~`!]"

for email in emails:
    if re.search(pattern, email):
        print(email)
