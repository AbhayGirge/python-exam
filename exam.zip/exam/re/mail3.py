# Question 3:
# Provide list of emails that start with numbers followed by underscore

import re

emails = [
    "2009_rocking_person@yahoo.com",
    "gaurav1234@gmail.com"
]

pattern = r"^[0-9]+_"

for email in emails:
    if re.search(pattern, email):
        print(email)
