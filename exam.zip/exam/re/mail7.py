# Question 6:
# Provide list of emails with only numbers before @

import re

emails = [
    "6789764666@rediffmail.com",
    "gaurav1234@gmail.com"
]

pattern = r"^[0-9]+@"

for email in emails:
    if re.search(pattern, email):
        print(email)
