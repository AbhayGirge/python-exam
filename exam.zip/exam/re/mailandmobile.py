# Question:
# Validate gmail and Indian mobile number using regex

import re

email = input("Enter email : ")
phone = input("Enter phone number : ")

email_pattern = r"^[a-zA-Z0-9._]+@gmail\.com$"

phone_pattern = r"^\+91[0-9]{10}$"

email_result = re.search(email_pattern, email)

phone_result = re.search(phone_pattern, phone)

if email_result and phone_result:
    print("Welcome User")
else:
    print("Invalid credentials")
