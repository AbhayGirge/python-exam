# Question 4:
# Provide list of emails that start with numbers followed by underscore or small letters

import re

emails = [
    "2009_rocking_person@yahoo.com",
    "2009abc@yahoo.com",
    "GodFather2022@yahoo.com"
]

pattern = r"^[0-9]+[_a-z]"

for email in emails:
    if re.search(pattern, email):
        print(email)
