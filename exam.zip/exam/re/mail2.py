# Question 2:
# Provide list of emails that start with numbers

import re

emails = [
    "gaurav1234@gmail.com",
    "2009_rocking_person@yahoo.com",
    "6789764666@rediffmail.com"
]

pattern = r"^[0-9]"

for email in emails:
    if re.search(pattern, email):
        print(email)
