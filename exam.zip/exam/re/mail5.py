# Question 5:
# Provide list of emails that start with numbers followed by underscore
# or small letters or capital letters

import re

emails = [
    "2009_rocking_person@yahoo.com",
    "2009ROCKING_PERSON@yahoo.com",
    "2009Abc@yahoo.com"
]

pattern = r"^[0-9]+[_a-zA-Z]"

for email in emails:
    if re.search(pattern, email):
        print(email)
