# Question 4:
# Library management system using private and class variables

class Book:

    # class variables
    library_name = "City Library"
    __library_turnover = 500000   # private class variable

    def __init__(self, book_name, book_author, cost_price):
        self.book_name = book_name
        self.book_author = book_author
        self.__cost_price = cost_price   # private variable

    # method to display private cost price
    def get_cost_price(self):
        return self.__cost_price

    # class method to display turnover
    @classmethod
    def get_library_turnover(cls):
        return cls.__library_turnover


# main
book1 = Book("Java", "James", 700)

# cannot access directly
# print(book1.__cost_price)  # error

print("Book Cost Price :", book1.get_cost_price())

# display library name
print("Library Name :", Book.library_name)

# display private class variable
print("Library Turnover :", Book.get_library_turnover())

# change library name using user input
new_name = input("Enter new library name : ")

Book.library_name = new_name

print("Updated Library Name :", Book.library_name)
