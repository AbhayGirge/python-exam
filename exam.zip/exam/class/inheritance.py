class Employee:
    # class variables
    organisation_name = "CDAC ACTS"

    # # Question: class methods get_organisation_name and set_organisation_name
    @classmethod
    def get_organisation_name(cls):
        return cls.organisation_name

    @classmethod
    def set_organisation_name(cls, org_name):
        cls.organisation_name = org_name

    def __init__(self, emp_id, name, base_location, deployed_location, designation, salary):
        # # Question: instance variables emp_id, name, base_location, deployed_location, designation, salary
        self.emp_id = emp_id
        self.name = name
        self.base_location = base_location
        self.deployed_location = deployed_location
        self.designation = designation
        self.salary = salary

    # # Question: get_employee_details()
    def get_employee_details(self):
        return f"ID: {self.emp_id} | Name: {self.name} | Desig: {self.designation} | Salary: {self.salary}"


class Manager(Employee):
    def __init__(self, emp_id, name, base_location, deployed_location, designation, salary, managed_employees=None):
        # Call parent constructor
        super().__init__(emp_id, name, base_location, deployed_location, designation, salary)
        # # Question: managed_employees[] list of references
        self.managed_employees = managed_employees if managed_employees else []

    # # Question: perform_appraisal_for_an_employee(emp_reference, percent_raise)
    def perform_appraisal_for_an_employee(self, emp_reference, percent_raise):
        increase = emp_reference.salary * (percent_raise / 100)
        emp_reference.salary += increase
        print(f"Appraisal Done! New salary for {emp_reference.name} is {emp_reference.salary}")

    # # Question: get_manager_details()
    def get_manager_details(self):
        base_details = self.get_employee_details()
        emp_names = [emp.name for emp in self.managed_employees]
        return f"Manager: {base_details}\nManaging: {', '.join(emp_names)}"

# --- Main ---
# 1) create 3 objects of Employee
e1 = Employee(101, "Alice", "Pune", "Pune", "Dev", 50000)
e2 = Employee(102, "Bob", "Pune", "Mumbai", "Tester", 45000)
e3 = Employee(103, "Charlie", "Pune", "Pune", "Dev", 52000)

# 2) create an object of Manager_class and add the employees
mgr = Manager(1, "Dheeraj", "Pune", "Pune", "Sr. Manager", 120000, [e1, e2, e3])

# 3) display get_manager_details()
print(mgr.get_manager_details())

# 4) perform appraisal
mgr.perform_appraisal_for_an_employee(e1, 10)
