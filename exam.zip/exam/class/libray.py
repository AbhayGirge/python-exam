# Question 3:
# Library management system with book details and purchase price

class Book:

    def __init__(self, book_name, book_author, cost_price):
        self.book_name = book_name
        self.book_author = book_author
        self.cost_price = cost_price

    def display_book_name(self):
        print("Book Name :", self.book_name)

    def display_book_author(self):
        print("Book Author :", self.book_author)

    def calculate_purchase_price(self, quantity):
        total = self.cost_price * quantity
        print("Total Cost :", total)


# main
book1 = Book("Python Basics", "Abhay", 500)

book1.display_book_name()
book1.display_book_author()

# cost of 10 books
book1.calculate_purchase_price(10)
