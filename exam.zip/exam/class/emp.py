# Question 1:
# Create Employee class with instance variables, class variable,
# getter/setter, class method and static method

class Employee:

    # class variable
    department_name = "IT"

    def __init__(self, emp_id, emp_salary, mgr_id):
        self.emp_id = emp_id
        self.__emp_salary = emp_salary   # private variable
        self.mgr_id = mgr_id

    # instance method
    def get_emp_salary(self):
        return self.__emp_salary

    # instance method
    def set_emp_salary(self, rcv_salary):
        self.__emp_salary = rcv_salary

    # class method
    @classmethod
    def get_department_name(cls):
        return cls.department_name

    # static method
    @staticmethod
    def field_expertise():
        print("Employees are experts in Python and DevOps")


# main
emp1 = Employee(100, 1000, 1)

# direct access
print("Employee ID :", emp1.emp_id)

# private variable cannot be accessed directly
# print(emp1.__emp_salary)   # gives error

print("Employee Salary :", emp1.get_emp_salary())

print("Manager ID :", emp1.mgr_id)

# class variable
print("Department :", Employee.get_department_name())

# static method
Employee.field_expertise()

# deleting attribute
del emp1.mgr_id

# deleting object
del emp1

print("Object deleted")
