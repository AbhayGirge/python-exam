# Question 2:
# Create Airline Ticket class and display ticket details

class Ticket:

    def __init__(self, departure, arrival, flight_no, seat):
        self.departure = departure
        self.arrival = arrival
        self.flight_no = flight_no
        self.seat = seat

    def display_ticket(self):
        print("Departure City :", self.departure)
        print("Arrival City :", self.arrival)
        print("Flight Number :", self.flight_no)
        print("Seat Number :", self.seat)
        print("------------------------")


# main
ticket1 = Ticket("Pune", "Delhi", "AI101", "12F")
ticket2 = Ticket("Mumbai", "Bangalore", "IN202", "10A")

print("Ticket 1 Details")
ticket1.display_ticket()

print("Ticket 2 Details")
ticket2.display_ticket()
