# Question:
# Create a generic dictionary by taking values from the user

employee = {}

# integer value
employee['employee_id'] = int(input("Enter employee id : "))

# string value
employee['employee_name'] = input("Enter employee name : ")

# large integer value
employee['account_number'] = int(input("Enter account number : "))

# float value
employee['salary'] = float(input("Enter salary : "))

# nested dictionary
home = input("Enter home address : ")

work = input("Enter work address : ")

employee['address'] = {
    'home_address': home,
    'work_address': work
}

# list value
award1 = input("Enter first award : ")

award2 = input("Enter second award : ")

employee['awards'] = [award1, award2]

# tuple value
subject1 = input("Enter first subject : ")

subject2 = input("Enter second subject : ")

employee['subjects_enrolled'] = (subject1, subject2)

# display dictionary
print("\nEmployee Dictionary")

print(employee)
