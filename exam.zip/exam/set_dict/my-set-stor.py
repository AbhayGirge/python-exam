# Question:
# Perform set operations using menu driven program

def set_union(setA, setB):

    print("Union :", setA | setB)


def set_intersection(setA, setB):

    print("Intersection :", setA & setB)


def set_minus(setA, setB):

    print("Difference :", setA - setB)


def is_member_of_set(setB):

    element = int(input("Enter element to search : "))

    if element in setB:
        print("Element found in Set B")

    else:
        print("Element not found in Set B")


def set_display(setA):

    print("Set Elements :", setA)

    print("Number of elements :", len(setA))


def set_add_element(setA):

    element = int(input("Enter element to add : "))

    setA.add(element)

    print("Updated Set :", setA)


def set_add_elements(setA):

    elements = input("Enter multiple elements separated by space : ")

    elements = elements.split()

    for i in elements:
        setA.add(int(i))

    print("Updated Set :", setA)


def set_remove_element(setA):

    element = int(input("Enter element to remove : "))

    if element in setA:

        setA.remove(element)

        print("Updated Set :", setA)

    else:
        print("Element not found")


def my_set_store():

    print("\nWelcome to Our Set Store !!!")

    setA = set()
    setB = set()

    # populate Set A
    elementsA = input("Enter elements for Set A separated by space : ")

    for i in elementsA.split():
        setA.add(int(i))

    # populate Set B
    elementsB = input("Enter elements for Set B separated by space : ")

    for i in elementsB.split():
        setB.add(int(i))

    while True:

        print("\n*************** Menu **********************")

        print("1: Union")
        print("2: Intersection")
        print("3: A-B")
        print("4: B-A")
        print("5: Check member in Set B")
        print("6: Display Set A")
        print("7: Display Set B")
        print("8: Add one element to Set A")
        print("9: Add multiple elements to Set A")
        print("10: Remove element from Set A")
        print("11: Exit")

        choice = int(input("Enter your choice : "))

        if choice == 1:
            set_union(setA, setB)

        elif choice == 2:
            set_intersection(setA, setB)

        elif choice == 3:
            set_minus(setA, setB)

        elif choice == 4:
            set_minus(setB, setA)

        elif choice == 5:
            is_member_of_set(setB)

        elif choice == 6:
            set_display(setA)

        elif choice == 7:
            set_display(setB)

        elif choice == 8:
            set_add_element(setA)

        elif choice == 9:
            set_add_elements(setA)

        elif choice == 10:
            set_remove_element(setA)

        elif choice == 11:
            print("Program Ended")
            break

        else:
            print("Invalid Input")


# main function call
my_set_store()
