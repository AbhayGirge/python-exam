# Question 7:
# Take a number from the user and calculate sum of all even numbers

num = int(input("Enter a number : "))

total = 0

for i in range(1, num + 1):

    if i % 2 == 0:
        total = total + i

print("Sum of even numbers :", total)
