# Question 5:
# Take a number from the user and print fibonacci sequence till that number

num = int(input("Enter a number : "))

a = 0
b = 1

print("Fibonacci Sequence :")

if num == 0:
    print(0)

else:
    print(a, end=" ")
    print(b, end=" ")

    while True:

        c = a + b

        if c > num:
            break

        print(c, end=" ")

        a = b
        b = c
