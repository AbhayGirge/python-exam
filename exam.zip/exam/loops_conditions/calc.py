# Question 2:
# Create my_calculator function for addition, square and exponentiation
# Keep running until user chooses to stop

def my_calculator(operation, num1, num2):

    if operation == "addition":
        return num1 + num2

    elif operation == "square":
        return num1 * num1

    elif operation == "power":
        return num1 ** num2

    else:
        return "Invalid Operation"


while True:

    print("1. addition")
    print("2. square")
    print("3. power")

    operation = input("Enter operation : ")

    num1 = int(input("Enter first number : "))
    num2 = int(input("Enter second number : "))

    result = my_calculator(operation, num1, num2)

    print("Result :", result)

    choice = input("Do you want to continue? (yes/no) : ")

    if choice == "no":
        print("Calculator Closed")
        break
