# Question 6:
# Take a number from the user and print multiplication table from 1 to 10

num = int(input("Enter a number : "))

for i in range(1, 11):

    print(num, "x", i, "=", num * i)
