# Question 1:
# Create a Fizz Buzz game and keep playing until user chooses to stop

while True:

    num = int(input("Enter a number : "))

    if num % 3 == 0 and num % 5 == 0:
        print("Fizz Buzz")

    elif num % 3 == 0:
        print("Fizz")

    elif num % 5 == 0:
        print("Buzz")

    else:
        print("Invalid Input")

    choice = input("Do you want to continue? (yes/no) : ")

    if choice == "no":
        print("Game Ended")
        break
