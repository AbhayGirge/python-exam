def string_display(string_input):
    if not string_input:
        print("The string is empty")
    else:
        print(f"The string is: '{string_input}'")
        print(f"Length of string: {len(string_input)} characters")

def display_3_4_5_element(string_input):
    if len(string_input) < 3:
        print("The string has fewer than 3 characters. Cannot display characters at positions 3, 4, and 5.")
    else:
        print("Characters at positions 3, 4, and 5 (0-indexed):")
        for i in range(2, min(5, len(string_input))):
            print(f"Position {i}: '{string_input[i]}'")

def string_retrieve_element(string_input):
    if not string_input:
        print("The string is empty")
        return
    
    try:
        subscript = int(input("Enter the subscript (index) to retrieve: "))
        if 0 <= subscript < len(string_input):
            print(f"Character at position {subscript}: '{string_input[subscript]}'")
        else:
            print(f"Invalid subscript! Please enter a number between 0 and {len(string_input)-1}")
    except ValueError:
        print("Invalid input! Please enter a valid number.")

def string_retrieve_elements(string_input):
    if not string_input:
        print("The string is empty")
        return
    
    try:
        start = int(input("Enter start subscript: "))
        end = int(input("Enter end subscript: "))
        
        if 0 <= start < len(string_input) and 0 <= end <= len(string_input):
            if start <= end:
                result = string_input[start:end]
                print(f"Characters from position {start} to {end-1}: '{result}'")
            else:
                print("Start subscript should be less than or equal to end subscript")
        else:
            print(f"Invalid subscripts! Please enter values between 0 and {len(string_input)}")
    except ValueError:
        print("Invalid input! Please enter valid numbers.")

def find_min_element(string_input):
    if not string_input:
        print("The string is empty")
    else:
        min_char = min(string_input)
        print(f"The minimum character in the string is: '{min_char}' (ASCII value: {ord(min_char)})")

def reverse_string(string_input):
    if not string_input:
        print("The string is empty")
    else:
        reversed_str = string_input[::-1]
        print(f"Original string: '{string_input}'")
        print(f"Reversed string: '{reversed_str}'")

def find_each_character_count(string_input):
    if not string_input:
        print("The string is empty")
    else:
        char_count = {}
        for char in string_input:
            char_count[char] = char_count.get(char, 0) + 1
        
        result_list = [(char, count) for char, count in char_count.items()]
        print("List of tuples (character, count):")
        for char, count in result_list:
            print(f"  '{char}': {count}")
        print(f"Full list: {result_list}")

def find_character_count_greater_than_1(string_input):
    if not string_input:
        print("The string is empty")
    else:
        char_count = {}
        for char in string_input:
            char_count[char] = char_count.get(char, 0) + 1
        
        result_list = [char for char, count in char_count.items() if count > 1]
        
        if result_list:
            print(f"Characters that appear more than once: {result_list}")
        else:
            print("No characters appear more than once in the string.")

def check_palindrome(string_input):
    if not string_input:
        print("The string is empty")
        return
    
    # Remove spaces and convert to lowercase for palindrome check
    cleaned_string = ''.join(string_input.lower().split())
    
    if cleaned_string == cleaned_string[::-1]:
        print(f"'{string_input}' IS a palindrome!")
        print(f"(When normalized: '{cleaned_string}' reads the same forwards and backwards)")
    else:
        print(f"'{string_input}' is NOT a palindrome.")
        print(f"(When normalized: '{cleaned_string}' does not read the same forwards and backwards)")

def my_string_store():
    print("\n Welcome to Our string Store !!! ")
    string_input = input("Please enter a string that you would want to perform Operation Upon").strip()

    while(True):
        print("\n*************** Menu **********************")
        print("Operations supported by our program are :")
        print("  1:  Display the string")
        print("  2:  Display third, fourth and fifth element from the string ")
        print("  3:  Retrieve element at a given subscript")
        print("  4:  Retrieve elements from a given subscript and to a given subscript")
        print(" 5:  Find minimum character in the string ")
        print(" 6:  Reverse the string ")
        print(" 7:  Output list of tuple(character, count) for each characters of the string  ")
        print(" 8:  Output list of characters of the string that appear more than once ")
        print(" 9:  Check if the string is a palindrome and return output message accordingly")
        print("  10: Exit the Program ")
        choice = int(input("Please enter your choice "))
        
        if choice == 1:
            string_display(string_input) 
        elif choice == 2:
            display_3_4_5_element(string_input) 
        elif choice == 3:
            string_retrieve_element(string_input)
        elif choice == 4:
            string_retrieve_elements(string_input) 
        elif choice == 5:
            find_min_element(string_input) 
        elif choice == 6:
            reverse_string(string_input) 
        elif choice == 7:
            find_each_character_count(string_input)
        elif choice == 8:
            find_character_count_greater_than_1(string_input)
        elif choice == 9:
            check_palindrome(string_input)
        elif choice == 10:
            print("Thank you for using the String Store!")
            break
        else:
            print("Invalid Input , Please Try Again !!!!")

my_string_store()
