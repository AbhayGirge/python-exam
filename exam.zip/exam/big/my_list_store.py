def list_display_members(members):
    if not members:
        print("The list is empty")
    else:
        print("Members in the list:")
        for i, member in enumerate(members):
            print(f"{i}: {member}")

def list_add_element(members):
    element = input("Enter the element to add (e.g., 'Sehwag'): ").strip()
    members.append(element)
    print(f"'{element}' added successfully!")

def list_add_elements(members):
    elements = input("Enter elements comma-separated (e.g., David,Bret,Sanju): ").strip().split(',')
    elements = [e.strip() for e in elements]
    members.extend(elements)
    print(f"{len(elements)} elements added successfully!")

def list_remove_element(members):
    if not members:
        print("The list is empty. Nothing to remove.")
        return
    
    try:
        subscript = int(input("Enter the subscript (index) to remove: "))
        if 0 <= subscript < len(members):
            removed = members.pop(subscript)
            print(f"'{removed}' removed from position {subscript}")
        else:
            print(f"Invalid subscript! Please enter a number between 0 and {len(members)-1}")
    except ValueError:
        print("Invalid input! Please enter a valid number.")

def remove_last_element(members):
    if not members:
        print("The list is empty. Nothing to remove.")
    else:
        removed = members.pop()
        print(f"'{removed}' removed from the end of the list")

def display_3_4_5_element(members):
    if len(members) < 3:
        print("The list has fewer than 3 elements. Cannot display elements at positions 3, 4, and 5.")
    else:
        print("Elements at positions 3, 4, and 5 (0-indexed):")
        for i in range(2, min(5, len(members))):
            print(f"Position {i}: {members[i]}")

def my_list_store():
    print("\n Welcome to Our List Store !!! ")
    print("Please enter a list Comma seperated that you would want to perform Operation Upon")
    
    # Populate the members collection with list of names
    user_input = input("Enter names comma-separated (e.g., John,Emma,Michael,Sarah): ").strip()
    if user_input:
        members = [name.strip() for name in user_input.split(',')]
    else:
        members = []  # Empty list if no input provided

    while(True):
        print("\n*************** Menu **********************")
        print("Operations supported by our program are :")
        print("  1:  Display all elements in the members list")
        print("  2:  Add an element to the members collection like 'Sehwag' ")
        print("  3:  Add elements to the members collection like ['David','Bret','Sanju']")
        print("  4:  Remove a member from the collection at a given subscript")
        print("  5:  Remove the last member from the collection ")
        print("  6:  Display third, fourth and fifth element from the collection ")
        print("  7: Exit the Program ")
        choice = int(input("Please enter your choice "))
        
        if choice == 1:
            list_display_members(members) 
        elif choice == 2:
            list_add_element(members) 
        elif choice == 3:
            list_add_elements(members)
        elif choice == 4:
            list_remove_element(members) 
        elif choice == 5:
            remove_last_element(members) 
        elif choice == 6:
            display_3_4_5_element(members) 
        elif choice == 7:
            print("Thank you for using the List Store!")
            break
        else:
            print("Invalid Input , Please Try Again !!!!")

my_list_store()
