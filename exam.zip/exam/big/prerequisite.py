# ============================================
# Python Prerequisites Setup for Beginners
# ============================================

# Step 1:
# Download and Install Python
# Website:
# https://www.python.org/downloads/

# While installing Python,
# make sure to select:
# ✔ Add Python to PATH

# --------------------------------------------

# Step 2:
# Check Python Installation

# Open terminal or command prompt and run:

# python --version

# OR

# python3 --version

# --------------------------------------------

# Step 3:
# Check pip Installation

# pip is Python package manager

# Run this command:

# pip --version

# --------------------------------------------

# Step 4:
# Install packages using pip

# Syntax:

# pip install package_name

# Example:

# pip install numpy

# pip install pandas

# pip install requests

# --------------------------------------------

# Step 5:
# Import modules in Python

# Some modules are already built into Python.
# No need to install them.

# Example built-in modules:

import os
import re
import math
import random

print("Built-in modules imported successfully")

# --------------------------------------------

# Step 6:
# External modules need installation using pip

# Example:
# pip install numpy

# Then import it:

# import numpy

# --------------------------------------------

# Common Modules and Their Use

# os      -> operating system operations
# re      -> regular expressions
# math    -> mathematical functions
# random  -> random values
# datetime -> date and time
# json    -> JSON handling

# --------------------------------------------

# Example using os module

import os

print("Current Working Directory :")
print(os.getcwd())

# --------------------------------------------

# Example using re module

import re

text = "Python123"

result = re.search("[0-9]", text)

if result:
    print("Number Found")

# --------------------------------------------

# Example using math module

import math

print("Square Root :", math.sqrt(25))

# --------------------------------------------

# Example using random module

import random

print("Random Number :", random.randint(1, 10))
