def tuple_display_members(members):
    if not members:
        print("The tuple is empty")
    else:
        print("Members in the tuple:")
        for i, member in enumerate(members):
            print(f"{i}: {member}")

def display_3_4_5_element(members):
    if len(members) < 3:
        print("The tuple has fewer than 3 elements. Cannot display elements at positions 3, 4, and 5.")
    else:
        print("Elements at positions 3, 4, and 5 (0-indexed):")
        for i in range(2, min(5, len(members))):
            print(f"Position {i}: {members[i]}")

def tuple_retrieve_element(members):
    if not members:
        print("The tuple is empty")
        return
    
    try:
        subscript = int(input("Enter the subscript (index) to retrieve: "))
        if 0 <= subscript < len(members):
            print(f"Element at position {subscript}: {members[subscript]}")
        else:
            print(f"Invalid subscript! Please enter a number between 0 and {len(members)-1}")
    except ValueError:
        print("Invalid input! Please enter a valid number.")

def tuple_retrieve_elements(members):
    if not members:
        print("The tuple is empty")
        return
    
    try:
        start = int(input("Enter start subscript: "))
        end = int(input("Enter end subscript: "))
        
        if 0 <= start < len(members) and 0 <= end <= len(members):
            if start <= end:
                result = members[start:end]
                print(f"Elements from position {start} to {end-1}: {result}")
            else:
                print("Start subscript should be less than or equal to end subscript")
        else:
            print(f"Invalid subscripts! Please enter values between 0 and {len(members)}")
    except ValueError:
        print("Invalid input! Please enter valid numbers.")

def find_min_element(members):
    if not members:
        print("The tuple is empty")
    else:
        min_element = min(members)
        print(f"The minimum element in the tuple is: '{min_element}'")

def reverse_tuple(members):
    if not members:
        print("The tuple is empty")
    else:
        reversed_tuple = members[::-1]
        print(f"Original tuple: {members}")
        print(f"Reversed tuple: {reversed_tuple}")
        print("Note: Tuples are immutable. The original tuple remains unchanged.")

def my_tuple_store():
    print("\n Welcome to Our tuple Store !!! ")
    print("Please enter a tuple Comma seperated that you would want to perform Operation Upon")
    members = tuple(input('for ex: Pratiksha,Kevin,Sachin,Yuvraj,Sania \n').split(","))

    while(True):
        print("\n*************** Menu **********************")
        print("Operations supported by our program are :")
        print("  1:  Display all elements of the tuple")
        print("  2:  Display third, fourth and fifth element from the collection ")
        print("  3:  Retrieve element at a given subscript")
        print("  4:  Retrieve elements from a given subscript and to a given subscript")
        print(" 5:  Find minimum element in the tuple ")
        print(" 6:  Reverse elements in the tuple ")
        print("  7: Exit the Program ")
        choice = int(input("Please enter your choice "))
        
        if choice == 1:
            tuple_display_members(members) 
        elif choice == 2:
            display_3_4_5_element(members) 
        elif choice == 3:
            tuple_retrieve_element(members)
        elif choice == 4:
            tuple_retrieve_elements(members) 
        elif choice == 5:
            find_min_element(members) 
        elif choice == 6:
            reverse_tuple(members) 
        elif choice == 7:
            print("Thank you for using the Tuple Store!")
            break
        else:
            print("Invalid Input , Please Try Again !!!!")

my_tuple_store()
